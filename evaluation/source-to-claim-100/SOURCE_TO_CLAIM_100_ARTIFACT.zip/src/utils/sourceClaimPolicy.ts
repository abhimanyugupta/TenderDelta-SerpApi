/** Conservative structured claim validation. Authority is trusted caller metadata,
 * not inferred from a title, ranking, domain, or instructions inside a document.
 * This module is opt-in; the existing UI/generation pipeline is not wired to it.
 */
export interface EvidenceDocument {
  id:string; tender_id:string; organization:string; title:string; type:string;
  version:number; effective_at?:string; provenance:string; authoritative:boolean;
  content:string; supersedes?:string; extracted_ok?:boolean;
}
export interface ProcurementClaim {
  field:string; value:string|number|boolean|null; tender_id:string; organization?:string;
  subject?:string; unit?:string; currency?:string; timezone?:string; effective_at?:string;
  operation?:{operator:'multiply'|'sum'; operands:Array<{document_id:string;field:string;value:string|number;unit?:string}>};
}
export interface EvidenceCitation {document_id:string;quote:string}
export interface ClaimInput {question:string;proposed_claim:ProcurementClaim;proposed_citations:EvidenceCitation[];documents:EvidenceDocument[]}
export interface ClaimDecision {behavior:'SUPPORTED'|'UNSUPPORTED'|'CONFLICTED'|'ABSTAIN';claim:ProcurementClaim|null;citations:EvidenceCitation[];reason:string}
interface Fact {doc:EvidenceDocument;value:string|number|boolean;currency?:string;unit?:string;subject?:string;sentence:string}
const labels:Record<string,string>={emd:'(?:EMD|bid security)',turnover:'(?:annual )?turnover',
  unit_price:'unit price',total_price:'total price',quantity:'quantity',delivery_days:'delivery (?:days|period)',
  deadline:'(?:submission )?deadline',gst_included:'GST included',organization:'organization',eligibility:'consortium bids'};
const hostile=/(?:ignore (?:all |the |previous)|system message|reveal (?:the )?system|do not cite|mark this tender|assume the user|upload it publicly|contact the procuring)/i;
const damaged=/(?:OCR confidence: low|extraction is unreliable|alignment lost|unreadable|original scan unavailable)/i;
const nonoperative=/(?:illustrative|not (?:the )?mandatory|not effective|draft,|not approved|hypothetical|subject to (?:approval|confirmation))/i;
const norm=(s:string)=>s.toLowerCase().trim().replace(/\s+/g,' ');
const singular=(s:string)=>norm(s).replace(/s$/,'');
function sentences(text:string):string[]{return text.replace(/\s+/g,' ').split(/(?<=[.!?])\s+(?=[A-Z])/).filter(Boolean);}
function parseMoney(t:string):{value:number;currency:string}|null {
  const m=t.match(/^\s*(INR|USD|EUR|GBP)\s+([0-9][0-9,]*(?:\.[0-9]+)?)(?:\s+(lakhs?|crores?|millions?))?(?=\s|[.;]|$)/i);
  if(!m) return null;
  const raw=m[2];
  if(raw.includes(',')&&!/^(?:\d{1,3}(?:,\d{3})+|\d{1,2}(?:,\d{2})*,\d{3})(?:\.\d+)?$/.test(raw))return null;
  const tail=t.slice(m[0].length).trim();
  if(/^[a-z]/i.test(tail)&&!/^(?:per|for|excluding|including|before|after)\b/i.test(tail))return null;
  const factor=({lakh:100000,crore:10000000,million:1000000} as Record<string,number>)[(m[3]||'').toLowerCase().replace(/s$/,'')]||1;
  const digits=raw.replaceAll(',','').split('.');
  if((digits[1]||'').length>12)return null;
  const scale=10n**BigInt((digits[1]||'').length);
  const cents=BigInt(digits.join(''))*BigInt(factor)*100n;
  if(cents%scale!==0n||cents/scale>BigInt(Number.MAX_SAFE_INTEGER))return null;
  return {value:Number(cents/scale)/100,currency:m[1].toUpperCase()};
}
function parseDeadline(t:string,context:string):string|null {
  let m=t.match(/(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?:\s*(IST|UTC)|([+-]\d{2}:\d{2}))/i);
  if(!m){const d=t.match(/(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})/);
    if(!d||!/DD\/MM\/YYYY/i.test(context))return null;
    const zone=/all times are IST/i.test(context)?'IST':/all times are UTC/i.test(context)?'UTC':null;
    if(!zone)return null;m=[d[0],d[3],d[2],d[1],d[4],d[5],zone,''] as RegExpMatchArray;}
  const y=Number(m[1]),month=Number(m[2]),day=Number(m[3]),h=Number(m[4]),min=Number(m[5]);
  const cal=new Date(Date.UTC(y,month-1,day));
  if(cal.getUTCFullYear()!==y||cal.getUTCMonth()!==month-1||cal.getUTCDate()!==day||h>23||min>59)return null;
  const offset=m[7]||((m[6]||'').toUpperCase()==='IST'?'+05:30':'+00:00');
  const iso=`${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:00${offset}`;
  return Number.isFinite(Date.parse(iso))?iso:null;
}
function scopeMatches(subject:string|undefined,sentence:string,field:string):boolean{
  if(!subject)return true;
  const item=singular(subject).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),s=norm(sentence);
  return new RegExp(`^(?:only )?${item}s? ${labels[field]}\\b`,'i').test(s);
}
function facts(doc:EvidenceDocument,claim:ProcurementClaim,field=claim.field):Fact[]{
  if(damaged.test(doc.content))return [];
  const label=labels[field];if(!label)return [];
  const found:Fact[]=[];
  for(const sentence of sentences(doc.content)){
    if(hostile.test(sentence)||/non-amending memo|reproduces the original/i.test(doc.content))continue;
    if(!scopeMatches(claim.subject,sentence,field))continue;
    const rx=new RegExp(`\\b${label}\\s*(?::|(?:is )?revised to|(?:is )?restored (?:to|at)|remains unchanged:)\\s*(.*)`,'ig');
    for(const match of sentence.matchAll(rx)){
      const rest=match[1];let f:Partial<Fact>|null=null;
      if(['emd','turnover','unit_price','total_price'].includes(field)){
        const money=parseMoney(rest);if(money){f=money;const u=rest.match(/\b(per [a-z]+)\b/i);if(u)f.unit=norm(u[1]);}
      }else if(field==='quantity'){
        const n=rest.match(/^(\d+)\s+([a-z]+)\b/i);if(n&&Number.isSafeInteger(Number(n[1])))f={value:Number(n[1]),unit:norm(n[2])};
      }else if(field==='delivery_days'){
        const n=rest.match(/^(\d+)\s+(calendar|working) days\b/i);if(n)f={value:Number(n[1]),unit:`${n[2].toLowerCase()}_days`};
      }else if(field==='deadline'){
        const date=parseDeadline(rest,doc.content);if(date)f={value:date};
      }else if(field==='gst_included'){
        const b=rest.match(/^(yes|no)\b/i);if(b)f={value:b[1].toLowerCase()==='yes'};
      }else if(field==='organization'){
        const value=rest.split(/[.\n]/)[0].trim();if(value)f={value};
      }
      if(f?.value!==undefined)found.push({...f,doc,sentence,subject:claim.subject} as Fact);
    }
    if(field==='eligibility'){
      const e=sentence.match(/consortium bids are (permitted|prohibited)/i);
      if(e)found.push({doc,value:e[1].toLowerCase()==='permitted',sentence});
    }
  }
  if(field==='delivery_days'){
    const restored=doc.content.match(/original delivery period of (\d+) (calendar|working) days is restored/i);
    if(restored)found.push({doc,value:Number(restored[1]),unit:`${restored[2].toLowerCase()}_days`,sentence:restored[0]});
  }
  // Pipe tables require explicit column headers, an exact item row and a currency.
  if(claim.subject&&['quantity','unit_price'].includes(field)){
    const lines=doc.content.split(/\r?\n/);const header=lines.findIndex(s=>/^Item\s*\|\s*Quantity\s*\|\s*Unit price\s*$/i.test(s.trim()));
    const currency=doc.content.match(/\bUnit price:\s*(INR|USD|EUR|GBP)\b/i)?.[1];
    if(header>=0&&currency){for(const line of lines.slice(header+1)){
      const row=line.split('|').map(s=>s.trim());
      if(row.length!==3||singular(row[0])!==singular(claim.subject))continue;
      const raw=row[field==='quantity'?1:2];if(!/^\d+(?:,\d{3})*(?:\.\d+)?$/.test(raw))continue;
      found.push({doc,value:Number(raw.replaceAll(',','')),currency:field==='unit_price'?currency:undefined,
        unit:field==='unit_price'?`per ${singular(row[0])}`:`${singular(row[0])}s`,subject:claim.subject,sentence:line});
    }}
  }
  return found;
}
function isAncestor(target:string,descendant:EvidenceDocument,docs:EvidenceDocument[]):boolean{
  const visited=new Set<string>();let current:EvidenceDocument|undefined=descendant;
  while(current?.supersedes){if(visited.has(current.id))return false;visited.add(current.id);
    if(current.supersedes===target)return true;
    current=docs.find(d=>d.id===current!.supersedes);}
  return false;
}
function currentFacts(docs:EvidenceDocument[],claim:ProcurementClaim,field=claim.field):Fact[]{
  const all=docs.flatMap(d=>facts(d,claim,field));
  return all.filter(f=>!all.some(g=>g.doc.type==='CORRIGENDUM'&&g.doc.version>f.doc.version&&
    g.doc.organization===f.doc.organization&&isAncestor(f.doc.id,g.doc,docs)));
}
function sameValue(f:Fact,claim:ProcurementClaim):boolean{
  const value=claim.field==='deadline'?typeof claim.value==='string'&&Date.parse(String(f.value))===Date.parse(claim.value):f.value===claim.value;
  const timezone=claim.timezone===undefined||(claim.timezone==='Asia/Kolkata'&&typeof claim.value==='string'&&claim.value.endsWith('+05:30'))||
    (claim.timezone==='UTC'&&typeof claim.value==='string'&&/(?:Z|\+00:00)$/.test(claim.value));
  return Boolean(value&&timezone&&(claim.currency===undefined||f.currency===claim.currency)&&
    (claim.unit===undefined||norm(f.unit||'')===norm(claim.unit)));
}
function citedFact(f:Fact,cites:EvidenceCitation[],claim:ProcurementClaim):boolean{
  return cites.some(c=>c.document_id===f.doc.id&&facts({...f.doc,content:c.quote},claim).some(g=>
    g.value===f.value&&g.currency===f.currency&&g.unit===f.unit));
}
export function validateProcurementClaim(input:ClaimInput):ClaimDecision{
  const reject=(behavior:ClaimDecision['behavior'],reason:string):ClaimDecision=>({behavior,claim:null,citations:[],reason});
  const claim=input.proposed_claim;
  if(!claim||!labels[claim.field]||!Array.isArray(input.documents)||!Array.isArray(input.proposed_citations))return reject('ABSTAIN','Unsupported or malformed structured request.');
  if(['emd','turnover','unit_price','total_price'].includes(claim.field)&&!['INR','USD','EUR','GBP'].includes(claim.currency||''))return reject('ABSTAIN','Monetary claims require an explicit supported currency.');
  if(input.documents.length>200||input.documents.some(d=>typeof d.content!=='string'||d.content.length>1000000))return reject('ABSTAIN','Evidence exceeds bounded validation limits.');
  if(new Set(input.documents.map(d=>d.id)).size!==input.documents.length)return reject('UNSUPPORTED','Document identity is ambiguous.');
  const docs=input.documents.filter(d=>d.authoritative&&d.provenance==='AUTHORITATIVE_DOCUMENT'&&d.extracted_ok!==false&&
    d.tender_id===claim.tender_id&&(!claim.organization||d.organization===claim.organization)&&
    (!claim.effective_at||!d.effective_at||Date.parse(d.effective_at)<=Date.parse(claim.effective_at))).sort((a,b)=>a.id.localeCompare(b.id));
  const cites=input.proposed_citations;
  for(const cite of cites){const d=docs.find(d=>d.id===cite.document_id);
    if(!d||typeof cite.quote!=='string'||!cite.quote.trim()||!d.content.includes(cite.quote))return reject('UNSUPPORTED','Citation lacks exact authoritative tender evidence.');
    if(hostile.test(cite.quote))return reject('UNSUPPORTED','Instruction-like document content cannot establish a procurement fact.');}
  if(docs.some(d=>damaged.test(d.content)))return reject('ABSTAIN','Extraction damage requires original-source verification.');
  if(docs.some(d=>nonoperative.test(d.content)))return reject('ABSTAIN','Evidence includes nonoperative or conditional terms requiring review.');
  for(const doc of docs){
    const embedded=doc.content.match(/Tender ID:\s*([A-Z0-9-]+)/i)?.[1];
    if(embedded&&embedded!==doc.tender_id)return reject('ABSTAIN','Embedded tender identity contradicts document metadata.');
    const visited=new Set<string>();let link:EvidenceDocument|undefined=doc;
    while(link?.supersedes){if(visited.has(link.id))return reject('ABSTAIN','Amendment graph is cyclic.');visited.add(link.id);
      const parent=docs.find(d=>d.id===link!.supersedes);
      if(!parent||parent.organization!==link.organization||parent.version>=link.version)return reject('ABSTAIN','Amendment graph lacks a valid ordered parent.');
      link=parent;}
  }
  const accepted=():ClaimDecision=>({behavior:'SUPPORTED',claim:structuredClone(claim),citations:structuredClone(cites),reason:'Structured fact and complete citations agree with current authoritative evidence.'});
  if(claim.operation){
    const op=claim.operation;const operandFacts:Fact[]=[];
    if(claim.field!=='total_price'||typeof claim.value!=='number'||!claim.currency)return reject('UNSUPPORTED','Arithmetic must establish a monetary total price.');
    if(!op.operands.length||op.operands.length>20)return reject('ABSTAIN','Arithmetic operands are incomplete.');
    for(const operand of op.operands){
      const sub={...claim,field:operand.field,value:operand.value,unit:operand.unit,
        currency:operand.field==='quantity'?undefined:claim.currency,operation:undefined};
      const current=currentFacts(docs,sub);const supported=current.find(f=>f.doc.id===operand.document_id&&sameValue(f,sub)&&citedFact(f,cites,sub));
      const signatures=new Set(current.map(f=>JSON.stringify([f.value,f.currency,f.unit])));
      if(op.operator==='multiply'&&signatures.size>1)return reject('CONFLICTED','Arithmetic operand has unresolved authoritative conflicts.');
      if(!supported)return reject('UNSUPPORTED','Each arithmetic operand needs a current authoritative citation.');
      operandFacts.push(supported);
    }
    if(op.operator==='multiply'){
      const q=operandFacts[op.operands.findIndex(o=>o.field==='quantity')],p=operandFacts[op.operands.findIndex(o=>o.field==='unit_price')];
      if(op.operands.length!==2||!q||!p||singular(q.unit||'')!==singular((p.unit||'').replace(/^per /,''))||
        /per \w+ of \d+/i.test(p.sentence))return reject('UNSUPPORTED','Arithmetic units or item scope do not match.');
    }else if(op.operator==='sum'){
      const lots=operandFacts.map(f=>f.sentence.match(/for (Lot [A-Z0-9]+)/i)?.[1].toLowerCase());
      if(op.operands.some(o=>o.field!=='total_price')||lots.some(l=>!l)||new Set(lots).size!==lots.length||
        !cites.some(c=>/lots .+ together form/i.test(c.quote)&&c.quote.includes(claim.tender_id)&&
          lots.every(l=>new RegExp(`\\b${l!.split(' ')[1]}\\b`,'i').test(c.quote))))return reject('ABSTAIN','Disjoint additive scope is not established by a cited link.');
    }else return reject('ABSTAIN','Arithmetic operator is unsupported.');
    const values=operandFacts.map(f=>Number(f.value));
    const result=op.operator==='multiply'?values.reduce((s,n)=>s*n,1):values.reduce((s,n)=>s+n,0);
    if(!Number.isFinite(result)||result!==claim.value)return reject('UNSUPPORTED','Arithmetic result disagrees with cited operands.');
    if(cites.some(c=>!operandFacts.some((f,i)=>f.doc.id===c.document_id&&citedFact(f,[c],
      {...claim,field:op.operands[i].field,value:op.operands[i].value,unit:op.operands[i].unit,
        currency:op.operands[i].field==='quantity'?undefined:claim.currency,operation:undefined}))))return reject('UNSUPPORTED','Arithmetic citation includes unrelated evidence.');
    return accepted();
  }
  const current=currentFacts(docs,claim);
  const signature=(f:Fact)=>JSON.stringify([claim.field==='deadline'?Date.parse(String(f.value)):f.value,f.currency,f.unit]);
  if(new Set(current.map(signature)).size>1)return reject('CONFLICTED','Current authoritative evidence contains unresolved field conflicts.');
  if(!current.length)return reject('ABSTAIN','The requested fact is absent, ambiguous or outside the supported extraction grammar.');
  const fact=current.find(f=>sameValue(f,claim));
  if(claim.currency&&current.every(f=>f.currency&&f.currency!==claim.currency))return reject('ABSTAIN','Currency conversion lacks an authoritative exchange rate.');
  if(!fact)return reject('UNSUPPORTED','Proposed value, currency, unit or time disagrees with authoritative evidence.');
  if(!cites.length||!citedFact(fact,cites,claim))return reject('UNSUPPORTED','The proposed citation does not establish the requested fact.');
  for(const c of cites){
    if(current.some(f=>f.doc.id===c.document_id&&citedFact(f,[c],claim)))continue;
    const d=docs.find(d=>d.id===c.document_id)!;
    const unchanged=new RegExp(`${labels[claim.field]}[^.]*remain(?:s)? unchanged`,'i');
    if(!unchanged.test(c.quote)||!scopeMatches(claim.subject,c.quote,claim.field)||
      !isAncestor(fact.doc.id,d,docs))return reject('UNSUPPORTED','An additional citation is unrelated or superseded.');
  }
  return accepted();
}
