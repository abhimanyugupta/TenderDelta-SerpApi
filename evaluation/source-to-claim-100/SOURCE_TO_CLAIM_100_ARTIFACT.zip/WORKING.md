# Evaluation state

- Goal: Complete the frozen 100-case source-to-claim adversarial evaluation in isolation.
- Changed: Dataset/schema/gold proofs, actual production baseline adapter, independent scorer, opt-in structured guard, separate actual extraction audit, reports and reproducibility documentation.
- Verification: Baseline 39/100; frozen guard 93/100 (development 73/75, held-out 20/25), 0 unsupported accepted claims among 19 accepted. Two false refusals and five refusal classifications remain. 277 independent property/regression checks, full existing suites, TypeScript, production build and 100 metamorphic checks passed.
- Next: Preserve this corpus and results. Independently review before any infrastructure integration. A separate authorized mission should integrate proof validation into the whole pipeline and use real authenticated documents with a new holdout.
- Boundary: Submission checkout/branch unchanged by this mission; no merges, pushes, API calls, installs, publication or submission. Guard is new production-capable code but is not connected to the existing app endpoints/UI.
- Commands: npm run eval:source-claim:baseline; npm run eval:source-claim:final; npm run eval:source-claim:extraction; npm run test:source-claim; npm run test:all; npm run lint; npm run build.
- Errors: Initial isolation clone/cache writes needed approved elevation; shell quoting and scorer parenthesis repaired; runner holdout manifest key corrected without policy changes. Build cache EPERM recovered by approved retry. Existing browser-external/bundle-size warnings remain.
- Limit: Actual unchanged extraction audit finds stale turnover, 0/18 deadline extraction and 100 ingestion-time draft placeholders. Benchmark results do not certify whole-app reliability.
