import { readFileSync,writeFileSync,mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
import { baseline } from './baseline';
import { inputFor,type Case,type Observation } from './types';
import { score,summarize } from './score';
import { validateCorpus } from './validate';
const root=join(process.cwd(),'tests/source_claim_100');
const corpus:Case[]=JSON.parse(readFileSync(join(root,'cases/cases.json'),'utf8'));
const manifest=JSON.parse(readFileSync(join(root,'manifest.json'),'utf8'));
const developmentOnly=process.argv.includes('--development');
const cases=developmentOnly?corpus.filter(c=>manifest.development_ids.includes(c.case_id)):corpus;
const digest=createHash('sha256').update(readFileSync(join(root,'cases/cases.json'))).digest('hex');
assert.equal(digest,manifest.dataset_sha256,'Frozen corpus changed; version dataset before evaluating.');
assert.equal(createHash('sha256').update(readFileSync(join(root,'schema/case.schema.json'))).digest('hex'),manifest.schema_sha256);
const sourceLock=JSON.parse(readFileSync(join(root,'baseline-source-lock.json'),'utf8'));
for(const [path,hash] of Object.entries(sourceLock.sha256)){
  assert.equal(createHash('sha256').update(readFileSync(join(process.cwd(),path),'utf8').replaceAll('\r\n','\n')).digest('hex'),hash,
    `Baseline production dependency changed: ${path}`);
}
for(const c of corpus){
  assert.deepEqual(JSON.parse(readFileSync(join(root,`cases/${c.case_id}.json`),'utf8')),c,'Individual case and frozen corpus differ.');
  const gold=JSON.parse(readFileSync(join(root,`expected/${c.case_id}.json`),'utf8'));
  for(const [key,value] of Object.entries(gold))assert.deepEqual(c[key],value,`Gold copy differs: ${c.case_id} ${key}`);
}
validateCorpus(corpus);
const phase=process.argv.includes('--final')?'final':'baseline';
const reportName=developmentOnly?`${phase}-development-run`:phase;
const adapter=phase==='baseline'?baseline:(await import('../../../src/utils/sourceClaimPolicy')).validateProcurementClaim;
// Guarantee the adapter never receives labels, rationales, case IDs or gold facts.
const results=cases.map(c=>score(c,adapter(inputFor(c))));
const development=cases.filter(c=>manifest.development_ids.includes(c.case_id));
const developmentResults=results.filter(r=>manifest.development_ids.includes(r.case_id));
const report={study:'TenderDelta structured proposed-claim validation; not a live LLM or entire-app reliability estimate',
  dataset_version:manifest.dataset_version,dataset_sha256:digest,baseline_commit:manifest.baseline_commit,phase,
  summary:summarize(cases,results),development:summarize(development,developmentResults),results};
Object.assign(report,{source_lock:sourceLock,holdout:developmentOnly?null:summarize(
  cases.filter(c=>manifest.sealed_holdout_ids.includes(c.case_id)),results.filter(r=>manifest.sealed_holdout_ids.includes(r.case_id))),
  policy_sha256:phase==='final'?createHash('sha256').update(readFileSync(join(process.cwd(),'src/utils/sourceClaimPolicy.ts'),'utf8').replaceAll('\r\n','\n')).digest('hex'):null,
  scorer_sha256:createHash('sha256').update(readFileSync(join(root,'runner/score.ts'),'utf8').replaceAll('\r\n','\n')).digest('hex')});
mkdirSync(join(root,'reports'),{recursive:true});
writeFileSync(join(root,`reports/${reportName}.json`),JSON.stringify(report,null,2)+'\n');
writeFileSync(join(root,`reports/${phase}-development.json`),JSON.stringify({summary:report.development,
  failures:developmentResults.filter(r=>!r.passed)},null,2)+'\n');
// Baseline console deliberately excludes sealed holdout examples.
console.log(JSON.stringify({phase,dataset_sha256:digest,development:report.development},null,2));

// Negative controls validate scorer discrimination, not production competence.
const alwaysAccept=cases.map(c=>score(c,{behavior:'SUPPORTED',claim:c.proposed_claim,citations:c.proposed_citations,reason:'broken accept-all'}));
const alwaysAbstain=cases.map(c=>score(c,{behavior:'ABSTAIN',claim:null,citations:[],reason:'broken refuse-all'}));
const oracle=cases.map(c=>score(c,{behavior:c.expected_behavior,claim:c.expected_behavior==='SUPPORTED'?c.expected_claim:null,
  citations:c.expected_behavior==='SUPPORTED'?c.expected_evidence:[],reason:'scorer oracle control'}));
assert.ok(alwaysAccept.some(r=>!r.passed));assert.ok(alwaysAbstain.some(r=>!r.passed));assert.ok(oracle.every(r=>r.passed));
writeFileSync(join(root,`reports/${reportName}-controls.json`),JSON.stringify({alwaysAccept:summarize(cases,alwaysAccept),
  alwaysAbstain:summarize(cases,alwaysAbstain),oracle:summarize(cases,oracle)},null,2)+'\n');

if(phase==='final'){
  const core=(o:Observation)=>({behavior:o.behavior,claim:o.claim,citations:[...o.citations].sort((a,b)=>a.document_id.localeCompare(b.document_id)),reason:o.reason});
  const shuffled=[...cases].sort((a,b)=>createHash('sha256').update('shuffle-v1'+a.case_id).digest('hex').localeCompare(
    createHash('sha256').update('shuffle-v1'+b.case_id).digest('hex')));
  let checked=0;
  for(const c of shuffled){const original=adapter(inputFor(c));const mutated=inputFor(c);
    mutated.documents.reverse();mutated.documents.forEach(d=>{d.content='Irrelevant formatting note.\n'+d.content;});
    assert.deepEqual(core(adapter(mutated)),core(original),`Metamorphic order/irrelevant-wording dependence: ${c.case_id}`);checked++;}
  writeFileSync(join(root,`reports/${reportName}-sanity.json`),JSON.stringify({caseOrderShuffled:true,documentOrderReversed:true,
    irrelevantWordingPerturbed:true,caseIdsExcludedFromAdapter:true,checked},null,2)+'\n');
}
