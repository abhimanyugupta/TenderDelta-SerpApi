import type {Case,Observation,Severity} from './types';
export const weights:Record<Severity,number>={S0:1,S1:2,S2:5,S3:10,S4:20,S5:40};
const equal = (a:unknown,b:unknown) => JSON.stringify(a)===JSON.stringify(b);
export function factEqual(a:any,b:any):boolean {
  if(!a||!b) return a===b;
  const operation=(o:any)=>o?{operator:o.operator,operands:[...o.operands].sort((x,y)=>
    JSON.stringify(x).localeCompare(JSON.stringify(y)))}:o;
  return ['field','value','tender_id','organization','subject','unit','currency','timezone','effective_at'].every(k=>
    b[k]===undefined || equal(a[k],b[k])) && (b.operation===undefined || equal(operation(a.operation),operation(b.operation)));
}
export function score(c:Case,o:Observation) {
  const emitted=o.claim!==null;
  const goldSupported=c.expected_behavior==='SUPPORTED';
  const factualCorrect=emitted && c.expected_claim!==null && factEqual(o.claim,c.expected_claim);
  const docs=[...c.source_documents,...c.distractor_documents];
  const syntactic=o.citations.every(x=>docs.some(d=>d.id===x.document_id && d.content.includes(x.quote)));
  const goldSpans=c.expected_evidence;
  const citationCorrect=o.citations.length>0 && syntactic && o.citations.every(x=>
    goldSpans.some(g=>g.document_id===x.document_id && x.quote.trim().length>0 && x.quote.includes(g.quote)));
  const citationComplete=goldSpans.length>0 && goldSpans.every(g=>o.citations.some(x=>
    x.document_id===g.document_id && x.quote.trim().length>0 && x.quote.includes(g.quote)));
  const wrongSource=emitted && o.citations.some(x=>!c.expected_citation.includes(x.document_id));
  const provenanceViolation=emitted && o.citations.some(x=>{const d=docs.find(d=>d.id===x.document_id);
    return !d||!d.authoritative||d.provenance!=='AUTHORITATIVE_DOCUMENT'||d.tender_id!==c.proposed_claim.tender_id;});
  const evidenceSupport=emitted && goldSupported && factualCorrect && citationCorrect && citationComplete;
  const refused=o.behavior==='ABSTAIN'||o.behavior==='UNSUPPORTED'||o.behavior==='CONFLICTED';
  const expectedRefusal=!goldSupported;
  const behaviorCorrect=o.behavior===c.expected_behavior ||
    (c.abstention_allowed && expectedRefusal && o.behavior==='ABSTAIN');
  const consistent=o.behavior==='SUPPORTED'?emitted:!emitted&&o.citations.length===0;
  const passed=consistent&&(goldSupported?behaviorCorrect&&evidenceSupport:behaviorCorrect&&!emitted);
  const errors:string[]=[];
  if(!consistent) errors.push('INCONSISTENT_OBSERVATION');
  if(emitted&&(!goldSupported||!factualCorrect)) errors.push('UNSUPPORTED_CLAIM');
  if(emitted&&c.expected_claim&&!factualCorrect) errors.push('INCORRECT_EXTRACTION');
  if(emitted&&!citationCorrect) errors.push('WRONG_CITATION');
  if(emitted&&!citationComplete) errors.push('INCOMPLETE_CITATION');
  if(wrongSource) errors.push('WRONG_SOURCE');
  if(provenanceViolation) errors.push('PROVENANCE_VIOLATION');
  if(goldSupported&&refused) errors.push('FALSE_ABSTENTION');
  if(!behaviorCorrect) errors.push('WRONG_BEHAVIOR');
  const observedSeverity:Severity=passed?'S0':emitted&&(!goldSupported||!factualCorrect)&&c.severity==='S5'?'S5':
    provenanceViolation?'S4':emitted&&(!goldSupported||!factualCorrect)?'S3':emitted&&!citationCorrect?'S4':
    goldSupported&&refused?'S2':'S2';
  return {case_id:c.case_id,category:c.category,passed,expected_behavior:c.expected_behavior,
    observation:o,factualCorrect,citationCorrect,citationComplete,evidenceSupport,behaviorCorrect,
    unsupportedClaim:emitted&&(!goldSupported||!factualCorrect),wrongSource,provenanceViolation,
    correctAbstention:expectedRefusal&&refused&&behaviorCorrect,falseAbstention:goldSupported&&refused,
    errors,severity:observedSeverity,weightedError:passed?0:weights[observedSeverity]};
}
export type Result=ReturnType<typeof score>;
const metric=(num:number,den:number)=>({numerator:num,denominator:den,rate:den?num/den:null});
export function summarize(cases:Case[],results:Result[]) {
  const subset=(pred:(c:Case)=>boolean)=>results.filter((_,i)=>pred(cases[i]));
  const supported=subset(c=>c.expected_behavior==='SUPPORTED');
  const refuse=subset(c=>c.expected_behavior==='UNSUPPORTED'||c.expected_behavior==='ABSTAIN');
  const emitted=results.filter(r=>r.observation.claim!==null);
  const conflicts=subset(c=>c.expected_behavior==='CONFLICTED');
  const temporal=subset(c=>c.category==='D'||c.category==='E');
  const numeric=subset(c=>c.category==='F');
  const categories=Object.fromEntries([...new Set(cases.map(c=>c.category))].map(k=>{
    const r=results.filter(x=>x.category===k);return[k,{total:r.length,passed:r.filter(x=>x.passed).length,
      errors:r.filter(x=>!x.passed).length,weightedErrors:r.reduce((s,x)=>s+x.weightedError,0)}];}));
  const catastrophic=results.filter(r=>!r.passed&&(r.severity==='S4'||r.severity==='S5'));
  const docsFor=(id:string)=>cases.find(c=>c.case_id===id)!;
  const emittedCitations=emitted.flatMap(r=>r.observation.citations.map(x=>({case:docsFor(r.case_id),citation:x})));
  const correctCitations=emittedCitations.filter(({case:c,citation:x})=>c.expected_evidence.some(g=>
    g.document_id===x.document_id&&x.quote.trim().length>0&&x.quote.includes(g.quote)&&
    [...c.source_documents,...c.distractor_documents].some(d=>d.id===x.document_id&&d.content.includes(x.quote))));
  const requiredSpans=cases.filter(c=>c.expected_behavior==='SUPPORTED').flatMap(c=>c.expected_evidence.map(g=>({case:c,span:g})));
  const coveredSpans=requiredSpans.filter(({case:c,span:g})=>results.find(r=>r.case_id===c.case_id)!.observation.claim!==null&&
    results.find(r=>r.case_id===c.case_id)!.observation.citations.some(x=>x.document_id===g.document_id&&
      x.quote.trim().length>0&&x.quote.includes(g.quote)&&[...c.source_documents,...c.distractor_documents].some(d=>
        d.id===x.document_id&&d.content.includes(x.quote))));
  return {total:results.length,passed:results.filter(r=>r.passed).length,
    metrics:{claimAccuracy:metric(emitted.filter(r=>r.factualCorrect).length,emitted.length),
      evidenceSupportAccuracy:metric(emitted.filter(r=>r.evidenceSupport).length,emitted.length),
      citationCorrectness:metric(correctCitations.length,emittedCitations.length),
      citationCompleteness:metric(coveredSpans.length,requiredSpans.length),
      unsupportedClaimRate:metric(results.filter(r=>r.unsupportedClaim).length,emitted.length),
      wrongSourceRate:metric(results.filter(r=>r.wrongSource).length,emitted.length),
      provenanceViolationRate:metric(results.filter(r=>r.provenanceViolation).length,emitted.length),
      correctAbstentionRate:metric(refuse.filter(r=>r.correctAbstention).length,refuse.length),
      falseAbstentionRate:metric(supported.filter(r=>r.falseAbstention).length,supported.length),
      conflictResolutionAccuracy:metric(conflicts.filter(r=>r.observation.behavior==='CONFLICTED').length,conflicts.length),
      temporalUpdateAccuracy:metric(temporal.filter(r=>r.passed).length,temporal.length),
      numericExtractionAccuracy:metric(numeric.filter(r=>r.passed).length,numeric.length)},
    rawErrors:results.filter(r=>!r.passed).length,
    errorCounts:Object.fromEntries([...new Set(results.flatMap(r=>r.errors))].sort().map(k=>[k,results.filter(r=>r.errors.includes(k)).length])),
    severityCounts:Object.fromEntries(Object.keys(weights).map(k=>[k,results.filter(r=>!r.passed&&r.severity===k).length])),
    weightedErrors:results.reduce((s,r)=>s+r.weightedError,0),
    severityWeightedReliability:Math.max(0,1-results.reduce((s,r)=>s+r.weightedError,0)/cases.reduce((s,c)=>s+weights[c.severity],0)),
    maximumSeverityObserved:results.filter(r=>!r.passed).reduce((m,r)=>Number(r.severity.slice(1))>Number(m.slice(1))?r.severity:m,'S0' as Severity),
    releaseGate:catastrophic.length?'FAIL_CATASTROPHIC_ERRORS':'NO_S4_S5_OBSERVED',
    catastrophicFailures:catastrophic.map(r=>r.case_id),categories};
}
