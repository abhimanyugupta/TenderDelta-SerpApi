import assert from 'node:assert/strict';
import type {Case} from './types';
export const taxonomy={A:10,B:10,C:10,D:10,E:8,F:8,G:8,H:8,I:8,J:6,K:6,L:6,R:2};
export function validateCorpus(cases:Case[]) {
  assert.equal(cases.length,100);assert.equal(new Set(cases.map(c=>c.case_id)).size,100);
  for(const [k,n] of Object.entries(taxonomy)) assert.equal(cases.filter(c=>c.category===k).length,n,k);
  for(const c of cases){
    for(const k of ['case_id','category','difficulty','source_documents','distractor_documents','authoritative_document',
      'question','proposed_claim','proposed_citations','expected_claim','expected_evidence','expected_citation',
      'expected_behavior','abstention_allowed','adversarial_property','severity','rationale']) assert.ok(k in c,`${c.case_id}: ${k}`);
    assert.match(c.case_id,/^[A-LR]\d{2}$/);assert.match(c.severity,/^S[0-5]$/);
    assert.ok(['SUPPORTED','UNSUPPORTED','CONFLICTED','ABSTAIN'].includes(c.expected_behavior));
    const docs=[...c.source_documents,...c.distractor_documents];
    assert.equal(new Set(docs.map(d=>d.id)).size,docs.length,`${c.case_id}: duplicate document identity`);
    for(const d of docs){assert.ok(d.id&&d.tender_id&&typeof d.content==='string');assert.ok(d.version>=1);}
    for(const g of c.expected_evidence){const d=docs.find(d=>d.id===g.document_id);
      assert.ok(d&&d.content.includes(g.quote),`${c.case_id}: gold span missing`);
      assert.ok(d.authoritative&&d.provenance==='AUTHORITATIVE_DOCUMENT',`${c.case_id}: untrusted gold`);}
    if(c.expected_behavior==='SUPPORTED'){
      assert.ok(c.expected_claim&&c.expected_evidence.length,`${c.case_id}: supported gold incomplete`);
      assert.ok(c.expected_evidence.every(e=>c.expected_citation.includes(e.document_id)));
    }
  }
}
