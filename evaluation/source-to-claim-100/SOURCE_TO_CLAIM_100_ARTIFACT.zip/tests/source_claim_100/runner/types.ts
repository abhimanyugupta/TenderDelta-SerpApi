export type Behavior = 'SUPPORTED' | 'UNSUPPORTED' | 'CONFLICTED' | 'ABSTAIN';
export type Severity = 'S0' | 'S1' | 'S2' | 'S3' | 'S4' | 'S5';
export interface Document {
  id: string; tender_id: string; organization: string; title: string;
  type: string; version: number; effective_at?: string;
  provenance: 'AUTHORITATIVE_DOCUMENT' | 'CANDIDATE_WEBPAGE' | 'SEARCH_DISCOVERY';
  authoritative: boolean; content: string; supersedes?: string; extracted_ok?: boolean;
}
export interface Claim {
  field: string; value: string | number | boolean | null; tender_id: string;
  organization?: string; subject?: string; unit?: string; currency?: string; timezone?: string; effective_at?: string;
  operation?: { operator: 'multiply' | 'sum'; operands: Array<{document_id: string; field: string; value: string | number; unit?: string}> };
}
export interface Citation { document_id: string; quote: string }
export interface Case {
  case_id: string; category: string; difficulty: string; source_documents: Document[];
  distractor_documents: Document[]; authoritative_document: string[]; question: string;
  proposed_claim: Claim; proposed_citations: Citation[]; expected_claim: Claim | null;
  expected_evidence: Citation[]; expected_citation: string[]; expected_behavior: Behavior;
  abstention_allowed: boolean; adversarial_property: string; severity: Severity; rationale: string;
}
// Gold labels, IDs, categories and rationales never reach the tested adapter.
export interface Input { question: string; proposed_claim: Claim; proposed_citations: Citation[]; documents: Document[] }
export interface Observation {
  behavior: Behavior; claim: Claim | null; citations: Citation[]; reason: string;
  diagnostics?: Record<string, unknown>;
}
export const inputFor = (c: Case): Input => ({question:c.question, proposed_claim:structuredClone(c.proposed_claim),
  proposed_citations:structuredClone(c.proposed_citations), documents:structuredClone([...c.source_documents,...c.distractor_documents])});
