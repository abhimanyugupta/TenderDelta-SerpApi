import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
import {runLocalGroundedAnalysis} from '../../../src/utils/analysisEngine';
import type {IngestionPipelineInput} from '../../../src/utils/analysisEngine';
import type {Case, Document} from './types';
import {validateCorpus} from './validate';

// Independent output audit. No evidence-policy adapter, proposed values,
// expected labels or benchmark case IDs are supplied to the extractor.
const root = new URL('../', import.meta.url);
const corpusBytes = readFileSync(new URL('cases/cases.json',root));
const cases: Case[] = JSON.parse(corpusBytes.toString());
const manifest = JSON.parse(readFileSync(new URL('manifest.json',root),'utf8'));
validateCorpus(cases);
const datasetHash = createHash('sha256').update(corpusBytes).digest('hex');
assert.equal(datasetHash,manifest.dataset_sha256,'Frozen corpus changed');
const frozenNow = Date.parse('2026-10-09T06:30:00Z');
const nativeDate = globalThis.Date;
const surface = new Set(['deadline','emd','turnover']);
type Status = 'CORRECT'|'WRONG'|'UNSCORABLE';
interface Output {
  field:string; channel:string; raw_value:unknown; normalized_value:string|number|null;
  currency?:string; document_id:string|null; quote:string;
  value_status:Status; source_status:Status; status:Status; reasons:string[]; cosmetic_span_padding?:boolean;
}

// Money conversion belongs only to the evaluation oracle. INR base units are
// compared, so 20 lakh and 2,000,000 are the same amount. No OCR repair occurs.
function money(value:unknown):number|null {
  if(typeof value === 'number') return Number.isFinite(value)?value:null;
  if(typeof value !== 'string') return null;
  const m = value.trim().match(/^(?:INR|Rs\.?|₹)?\s*([\d,]+(?:\.\d+)?)[.]?\s*(crores?|cr|lakhs?|lacs?|million)?\s*(?:\/-)?\s*$/i);
  if(!m) return null;
  const number = Number(m[1].replace(/,/g,''));
  const unit = (m[2]||'').toLowerCase();
  const multiplier = /^(crore|cr)/.test(unit)?10000000:/^(lakh|lac)/.test(unit)?100000:/^million/.test(unit)?1000000:1;
  return Number.isFinite(number)?number*multiplier:null;
}
function sameValue(out:Output,c:Case):boolean|null {
  const gold = c.expected_claim;
  if(!gold || gold.field!==out.field || !c.expected_evidence.length) return null;
  if(out.field==='deadline') {
    if(typeof gold.value!=='string' || !/[zZ]|[+-]\d{2}:\d{2}$/.test(gold.value)) return null;
    const expected = nativeDate.parse(gold.value);
    const actual = typeof out.normalized_value==='string'?nativeDate.parse(out.normalized_value):NaN;
    return Number.isFinite(expected)&&Number.isFinite(actual)?expected===actual:false;
  }
  if(typeof gold.value!=='number')return null;
  return out.normalized_value === gold.value && (!gold.currency || gold.currency===out.currency);
}
function inspect(out:Output,c:Case,documents:Document[]):Output {
  const doc = documents.find(d=>d.id===out.document_id);
  if(!doc) {out.source_status='WRONG';out.reasons.push('Source document is absent or ambiguous.');}
  else {
    const sourceErrors:string[]=[];
    if(!doc.authoritative||doc.provenance!=='AUTHORITATIVE_DOCUMENT')sourceErrors.push('Emitted fact cites discovery/webpage evidence.');
    if(doc.tender_id!==c.proposed_claim.tender_id)sourceErrors.push('Emitted fact cites a different tender.');
    if(doc.extracted_ok===false)sourceErrors.push('Emitted fact cites failed extraction.');
    // The production regex can consume document-join newlines at a span's end.
    // Trimming only boundary whitespace is semantic-preserving and avoids
    // misclassifying this cosmetic artifact as a wrong-source violation.
    if(!out.quote.trim() || !doc.content.includes(out.quote.trim()))sourceErrors.push('Quoted extraction does not occur in its named document.');
    else if(!doc.content.includes(out.quote))out.cosmetic_span_padding=true;
    if(c.expected_claim?.field===out.field && c.expected_evidence.length && !c.expected_citation.includes(doc.id))sourceErrors.push('Source is not a gold supporting document for this field.');
    out.source_status=sourceErrors.length?'WRONG':'CORRECT';out.reasons.push(...sourceErrors);
  }
  const match=sameValue(out,c);
  out.value_status=match===null?'UNSCORABLE':match?'CORRECT':'WRONG';
  if(match===false)out.reasons.push('Actual emitted field value/currency differs from explicit authoritative gold.');
  if(match===null)out.reasons.push('No independently adjudicated explicit gold value for this emitted field; excluded from value accuracy.');
  out.status=out.value_status==='WRONG'||out.source_status==='WRONG'?'WRONG':out.value_status==='CORRECT'&&out.source_status==='CORRECT'?'CORRECT':'UNSCORABLE';
  return out;
}
function count(outputs:Output[]) {
  return Object.fromEntries(['CORRECT','WRONG','UNSCORABLE'].map(status=>[status,outputs.filter(o=>o.status===status).length]));
}
const caseRows: Array<Record<string,any>>=[];
// Freeze Date in memory only. Runtime-generated IDs and task timestamps never
// enter scoring. This exposes ingestion-time deadline placeholders reproducibly.
globalThis.Date = new Proxy(nativeDate,{
  construct:(target,args)=>Reflect.construct(target,args.length?args:[frozenNow]),
  apply:()=>new nativeDate(frozenNow).toString(),
  get:(target,key)=>key==='now'?()=>frozenNow:Reflect.get(target,key)
}) as typeof Date;
try {
  for(const c of cases) {
    const documents=[...c.source_documents,...c.distractor_documents];
    const filenames=new Map(documents.map(d=>[d.id,`${d.id}.txt`]));
    const ingested=(d:Document)=>({id:d.id,filename:filenames.get(d.id)!,fileSizeBytes:Buffer.byteLength(d.content),
      type:d.type as IngestionPipelineInput['originalDocs'][number]['type'],pageCount:0,
      extractedText:d.extracted_ok===false?'':d.content});
    const result=runLocalGroundedAnalysis({title:'Offline extraction audit',referenceNumber:c.proposed_claim.tender_id,
      organization:'',portal:'CUSTOM',estimatedValueInr:0,
      originalDocs:documents.filter(d=>d.type!=='CORRIGENDUM').map(ingested),
      corrigendaDocs:documents.filter(d=>d.type==='CORRIGENDUM').map(ingested)});
    const resolve=(filename:string|undefined)=>documents.find(d=>filenames.get(d.id)===filename)?.id||null;
    const outputs:Output[]=result.requirements.map(r=>{
      const field=r.key==='EMD_AMOUNT'?'emd':r.key==='FINANCIAL_TURNOVER'?'turnover':r.key;
      const currency=r.normalizedValue?.currency;
      return inspect({field,channel:'requirements',raw_value:r.currentValue,normalized_value:money(r.currentValue),currency,
        document_id:resolve(r.sourceCitation?.documentName),quote:r.sourceCitation?.exactSnippet||'',
        value_status:'UNSCORABLE',source_status:'UNSCORABLE',status:'UNSCORABLE',reasons:[]},c,documents);
    });
    for(const deadline of result.deadlines) outputs.push(inspect({field:'deadline',channel:'deadlines',
      raw_value:deadline.currentDate,normalized_value:result.draftTender.currentSubmissionDeadline,
      document_id:resolve(deadline.sourceCitation?.documentName||deadline.sourceDocumentName),quote:deadline.sourceCitation?.exactSnippet||'',
      value_status:'UNSCORABLE',source_status:'UNSCORABLE',status:'UNSCORABLE',reasons:[]},c,documents));
    const hasExplicitGold=Boolean(c.expected_claim&&c.expected_evidence.length);
    const targetOutputs=outputs.filter(o=>o.field===c.expected_claim?.field);
    const fallback=result.deadlines.length===0&&result.draftTender.currentSubmissionDeadline===new nativeDate(frozenNow).toISOString();
    caseRows.push({case_id:c.case_id,category:c.category,gold_field:c.expected_claim?.field||null,
      has_explicit_gold:hasExplicitGold,extractor_surface_eligible:hasExplicitGold&&surface.has(c.expected_claim!.field),
      target_emitted:targetOutputs.length>0,target_correct:targetOutputs.some(o=>o.status==='CORRECT'),
      outputs,emitted_counts:count(outputs),generated_changes:result.changes.length,
      draft_deadline:{value:result.draftTender.currentSubmissionDeadline,is_ingestion_time_fallback:fallback,
        classification:fallback?'UNGROUNDED_PLACEHOLDER':result.deadlines.length?'EXTRACTED_VALUE':'UNSCORABLE',
        explanation:fallback?'No deadline was extracted; the returned draft uses ingestion time as its current submission deadline. This is not counted as an extracted fact.':undefined}});
  }
} finally {globalThis.Date=nativeDate;}
const outputs=caseRows.flatMap(r=>r.outputs as Output[]);
const valueScorable=outputs.filter(o=>o.value_status!=='UNSCORABLE');
const goldRows=caseRows.filter(r=>r.has_explicit_gold);
const eligible=caseRows.filter(r=>r.extractor_surface_eligible);
const conflictEmissions=caseRows.flatMap(row=>{
  const c=cases.find(c=>c.case_id===row.case_id)!;
  return c.expected_behavior==='CONFLICTED'?(row.outputs as Output[]).filter(o=>o.field===c.proposed_claim.field).map(o=>
    ({case_id:c.case_id,field:o.field,value:o.normalized_value,document_id:o.document_id,
      classification:'UNSAFE_UNRESOLVED_CONFLICT',threat_severity:c.severity})):[];
});
const rate=(n:number,d:number)=>({numerator:n,denominator:d,rate:d?n/d:null});
const fieldCounts=Object.fromEntries([...new Set([...surface,...outputs.map(o=>o.field)])].sort().map(field=>[field,{
  emitted_output_counts:count(outputs.filter(o=>o.field===field)),
  explicit_gold_cases:goldRows.filter(r=>r.gold_field===field).length,
  target_emitted:goldRows.filter(r=>r.gold_field===field&&r.target_emitted).length,
  target_correct:goldRows.filter(r=>r.gold_field===field&&r.target_correct).length
}]));
const report={audit_version:'1.0.0',dataset_version:manifest.dataset_version,dataset_sha256:datasetHash,
  baseline_commit:manifest.baseline_commit,clock_utc:new nativeDate(frozenNow).toISOString(),cases:cases.length,
  architecture:'Unchanged runLocalGroundedAnalysis actual output audit; gold enters scoring only after extraction.',
  metrics:{emitted_output_counts:count(outputs),emitted_value_accuracy:rate(valueScorable.filter(o=>o.value_status==='CORRECT').length,valueScorable.length),
    emitted_source_grounding_accuracy:rate(outputs.filter(o=>o.source_status==='CORRECT').length,outputs.length),
    cosmetic_span_boundary_padding:outputs.filter(o=>o.cosmetic_span_padding).length,
    supported_surface_extraction_coverage:rate(eligible.filter(r=>r.target_emitted).length,eligible.length),
    supported_surface_grounded_correct_coverage:rate(eligible.filter(r=>r.target_correct).length,eligible.length),
    all_explicit_gold_field_extraction_coverage:rate(goldRows.filter(r=>r.target_emitted).length,goldRows.length),
    draft_ingestion_time_deadline_placeholders:caseRows.filter(r=>r.draft_deadline.is_ingestion_time_fallback).length,
    unsafe_unresolved_conflict_emissions:conflictEmissions.length},
  unsafe_conflict_examples:conflictEmissions,
  by_field:fieldCounts,by_category:Object.fromEntries([...new Set(cases.map(c=>c.category))].sort().map(category=>{
    const rows=caseRows.filter(r=>r.category===category);return [category,{cases:rows.length,emitted_output_counts:count(rows.flatMap(r=>r.outputs)),
      explicit_gold_cases:rows.filter(r=>r.has_explicit_gold).length,target_emitted:rows.filter(r=>r.target_emitted).length,
      target_correct:rows.filter(r=>r.target_correct).length}];})),
  limitations:[
    'Scores actual structured requirements/deadlines, not validator acceptance or arbitrary Q&A answers.',
    'Only deadline, EMD and turnover have direct target mappings in the current text extractor. Other gold fields affect full-corpus coverage but are outside its implemented surface.',
    'Unscorable emissions have no explicit gold for that field and are excluded from value accuracy; their physical source identity is still audited.',
    'Unscorable value outputs can still be unsafe: emissions from adjudicated CONFLICTED cases are separately counted as unsafe unresolved conflicts. Value precision and source-span presence must not be interpreted as safe extraction accuracy.',
    'Source authority, tender identities and extracted_ok are fixture metadata assumptions; ingestion cannot express the original discovery/authority hierarchy.',
    'ID-derived unique filenames provide unambiguous citation document mapping. Generated runtime tender IDs are not compared with procurement tender IDs.',
    'No PDF parsing, OCR execution, network, model inference or live source authentication is exercised.',
    'Changes/tasks repeat extracted values and are counted diagnostically, not as independent facts. Risk scores and generated IDs are not correctness metrics.',
    'Missing extraction is a coverage failure, not a wrong-value emission. Draft ingestion-time deadlines are reported separately and must not be interpreted as supported deadline facts.',
    'Gold-source membership and source-span presence after boundary whitespace trimming are necessary checks; this audit does not establish full citation completeness or general semantic entailment.',
    'Source grounding requires a known authoritative matching-tender document, source-span presence, and gold-source membership when the target field has an adjudicated gold value. Boundary-only whitespace padding is counted as cosmetic.'
  ],case_results:caseRows};
mkdirSync(new URL('reports/',root),{recursive:true});
writeFileSync(new URL('reports/extraction-audit.json',root),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({cases:report.cases,metrics:report.metrics,by_field:report.by_field},null,2));
