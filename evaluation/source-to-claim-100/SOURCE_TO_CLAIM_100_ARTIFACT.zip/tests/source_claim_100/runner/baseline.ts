import { validateMaterialChange, retrieveBoundedSourceContext } from '../../../src/utils/evidenceValidator';
import { runLocalGroundedAnalysis } from '../../../src/utils/analysisEngine';
import type { Input, Observation } from './types';
import type { TenderDocument, MaterialChange } from '../../../src/types';

// Frozen adapter over existing production code. It intentionally does not add
// semantic/authority checks absent from that implementation.
export function baseline(input: Input): Observation {
  const documents: TenderDocument[] = input.documents.map(d => ({
    id:d.id, tenderId:d.tender_id, name:d.title, filename:d.title, type:d.type as any,
    versionNumber:d.version, versionLabel:`v${d.version}.0`, pageCount:0,fileSizeBytes:d.content.length,
    extractedText:d.extracted_ok === false ? '' : d.content,
    provenance:d.provenance === 'AUTHORITATIVE_DOCUMENT' ? 'USER_UPLOADED' : d.provenance as any,
  }));
  const retrieval = retrieveBoundedSourceContext(documents, {characterBudget:10000});
  // Exercise the actual deterministic source-to-analysis path for diagnostics.
  const analyzed = runLocalGroundedAnalysis({title:'Evaluation source',referenceNumber:input.proposed_claim.tender_id,
    organization:input.proposed_claim.organization || '',portal:'CUSTOM',estimatedValueInr:0,
    originalDocs:documents.filter(d=>d.type!=='CORRIGENDUM').map(d=>({id:d.id,filename:d.name,type:d.type,
      pageCount:0,fileSizeBytes:d.fileSizeBytes,extractedText:d.extractedText})),
    corrigendaDocs:documents.filter(d=>d.type==='CORRIGENDUM').map(d=>({id:d.id,filename:d.name,type:d.type,
      pageCount:0,fileSizeBytes:d.fileSizeBytes,extractedText:d.extractedText})),
  });
  const checked = input.proposed_citations.map(c => validateMaterialChange({
    id:'candidate', tenderId:input.proposed_claim.tender_id, category:'TECHNICAL',changeType:'MODIFIED',
    materiality:'HIGH',confidence:'HIGH',confidenceReason:'Proposed claim',title:input.question,
    requirementKey:input.proposed_claim.field,originalText:'',updatedText:String(input.proposed_claim.value),
    impactExplanation:'',actionRequired:'',affectedDocuments:[],relevantRoles:[],verificationStatus:'UNREVIEWED',
    sourceCitation:{documentId:c.document_id,sourceDocumentId:c.document_id,
      documentName:documents.find(d=>d.id===c.document_id)?.name || '',exactSnippet:c.quote},
  } as MaterialChange, documents));
  const supported = checked.length>0 && checked.every(c=>!c.isQuarantined && c.isVerifiedAgainstSource);
  return {behavior:supported?'SUPPORTED':input.proposed_citations.length?'UNSUPPORTED':'ABSTAIN',
    claim:supported?input.proposed_claim:null,citations:supported?input.proposed_citations:[],
    reason:supported?'Current production validator verifies quoted source, without checking claim entailment.':'Current production citation validation did not support the candidate.',
    diagnostics:{retrievalCoverage:retrieval.coverage,generatedRequirements:analyzed.requirements.length,
      generatedChanges:analyzed.changes.length,generatedDeadlines:analyzed.deadlines.length}};
}
